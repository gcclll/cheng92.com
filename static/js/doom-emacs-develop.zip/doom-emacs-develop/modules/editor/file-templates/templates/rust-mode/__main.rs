fn main() {
    ${0:println!("Hello, world!");}
}

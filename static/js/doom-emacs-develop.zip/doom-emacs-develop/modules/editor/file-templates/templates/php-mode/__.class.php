<?php

class `(doom/php-class-name)`$1 {

    $0

}

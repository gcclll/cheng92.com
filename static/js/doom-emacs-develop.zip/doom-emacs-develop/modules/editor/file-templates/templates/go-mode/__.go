package ${1:main}

import (
   "fmt"
)

$0